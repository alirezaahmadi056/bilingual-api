<?php $__env->startSection('Title'); ?>
افزودن مقاله
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-center items-center mt-20">
    <form class="flex flex-col gap-5 w-[37rem]" action="<?php echo e(route("articles.store")); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input name="title" type="text" class=" rounded-md border-[#B2B2B2]" placeholder="تایتل">
        <textarea name="description" id="editor" cols="30" rows="10" class=" rounded-md border-[#B2B2B2]" placeholder="توضیحات"></textarea>
        <label for="image">عکس:</label>
        <input type="file" name="image" id="">
        <button type="submit" class="bg-primary w-full text-[#FFFFFF] text-xl py-2 rounded-xl">ثبت</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    ClassicEditor
        .create( document.querySelector( '#editor' ),{
            language: 'fa'
        } )
        .catch( error => {
            console.error( error );
        } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/seyed/Desktop/Projects/bilingual/resources/views/articles/create.blade.php ENDPATH**/ ?>