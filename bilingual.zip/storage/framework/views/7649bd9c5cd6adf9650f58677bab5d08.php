<?php $__env->startSection('Title'); ?>
ثبت اسلایدر
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-center items-center mt-20">
    <form class="flex flex-col gap-y-10" action="<?php echo e(route("sliders.update",$slider->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
        <img src="<?php echo e(asset("slider_image/".$slider->image)); ?>" class="w-96 rounded-xl shadow-2xl" alt="">
        <input type="hidden" name="beforeimage" value="<?php echo e($slider->image); ?>">
        <div class="flex flex-col gap-3">
            <label for="link">لینک</label>
            <select name="link" id="" class="border-[1px] border-[#B2B2B2] rounded-xl py-3 px-8">
                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($page->inapp); ?>"><?php echo e($page->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="flex flex-col gap-3">
            <label for="Upload">تصویر</label>
            <input name="image" type="file">
        </div>
        <div class="flex justify-center items-center">
            <button type="submit" class="bg-[#5D001E] rounded-md text-[#FFFFFF] p-3 flex items-center gap-2"><img src="./Icon/gallery-add.svg" alt="">ثبت اسلایدر</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/seyed/Desktop/Projects/bilingual/resources/views/sliders/edit.blade.php ENDPATH**/ ?>