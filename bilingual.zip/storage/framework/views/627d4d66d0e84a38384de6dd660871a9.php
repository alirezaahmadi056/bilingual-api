<?php $__env->startSection('Title'); ?>
فصل ها
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-center items-center gap-3">
    <button class="rounded-xl px-4 py-2 flex items-center text-primary max-sm:text-sm text-xl border-[1px] border-primary my-8"><img src="<?php echo e(asset("Icon/add.svg")); ?>" alt=""><a href="<?php echo e(route("seasons.create",$id)); ?>">افزودن فصل</a></button>
    <button class="border-primary border-[1px] py-2 px-4 flex justify-center items-center gap-1 text-xl rounded-xl text-primary"><img src="<?php echo e(asset("/Icon/add.svg")); ?>" alt=""><a href="<?php echo e(route("seasons.sub.create",$editid)); ?>">افزودن زیرفصل</a></button>
    <button class="border-[1px] border-primary py-2 px-4 flex justify-center max-sm:text-sm text-xl items-center gap-2 rounded-xl text-primary"><img src="<?php echo e(asset("/Icon/video-add.svg")); ?>" alt=""><a href="<?php echo e(route("episodes.show",$editid)); ?>">آپلود ویدیو</a></button>
</div>
<div class="container mx-auto flex flex-col justify-center items-center">
    <?php $__currentLoopData = $seasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $season): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-[#F9F9F9] px-4 py-3 rounded-tl-xl mt-5 rounded-tr-xl w-[52rem] max-sm:w-96 flex justify-between items-center border-[1px] border-[#B2B2B2]">
        <h1 class="text-xl font-bold"><?php echo e($season->title); ?></h1>
        <div class="flex justify-center items-center gap-5">
            <form action="<?php echo e(route("seasons.destroy",$season->id)); ?>" method="post" class=" mt-4">
                <?php echo csrf_field(); ?>
                <?php echo method_field("DELETE"); ?>
                <button class="bg-primary py-2 px-4 flex justify-center items-center gap-2 rounded-md text-[#FFFFFF]"><img src="<?php echo e(asset("/Icon/trash.svg")); ?>" alt="">حذف</button>
            </form>
        </div>
    </div>

    <ul class=" w-[52rem] max-sm:w-96 border-[1px] border-[#B2B2B2] rounded-bl-xl rounded-br-xl">
        <?php $__currentLoopData = $season->episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $episode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="px-12">
                <div class="flex justify-between py-7 px-4 border-b-[1px] border-[#B2B2B2]">
                    <h1><?php echo e($episode->title); ?></h1>
                    <form action="<?php echo e(route("episodes.destroy",$episode->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>
                        <button class="flex items-center gap-1 text-primary"><img class="w-[20px]" src="<?php echo e(asset("Icon/trash-1.svg")); ?>" alt="">حذف</button>
                    </form>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/seyed/Desktop/Projects/bilingual/resources/views/season.blade.php ENDPATH**/ ?>