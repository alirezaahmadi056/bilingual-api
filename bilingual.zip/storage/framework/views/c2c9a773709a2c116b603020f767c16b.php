<?php $__env->startSection('Title'); ?>
کامنت های دوره <?php echo e($name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-center mt-20 gap-7 max-sm:flex-col">
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class=" shadow-lg rounded-md py-3 px-5 w-64 border-[1px] border-[#B2B2B2] flex flex-col">
            <h1 class="text-xl">نام کاربر:<?php echo e($comment->title); ?></h1>
            <h1 class="mt-2">امتیاز:<span><?php echo e($comment->points); ?></span></h1>
            <p class="mt-2">متن:<span><?php echo e($comment->description); ?></span></p>
            <div class="flex items-center gap-3 mt-3">
                <form action="<?php echo e(route("comment.update",$comment->id)); ?>" method="post" class="basis-2/4">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PUT"); ?>
                    <button class="bg-primary basis-2/4 rounded-md py-2 w-full text-[#FFFFFF]">تایید</button>
                </form>
                <form class=" basis-2/4" action="<?php echo e(route("comment.destroy",$comment->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("DELETE"); ?>
                    <button type="submit" class="border-[1px] border-primary py-2 w-full rounded-md">حذف کردن</button>
                </form>
            </div>
            <button class="bg-primary rounded-md py-2 w-full text-[#FFFFFF]"><a href="<?php echo e(route("comment.edit",$comment->id)); ?>">ویرایش</a></button>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/seyed/Desktop/Projects/bilingual/resources/views/comments/show.blade.php ENDPATH**/ ?>