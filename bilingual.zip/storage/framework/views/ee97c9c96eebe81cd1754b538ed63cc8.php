<?php $__env->startSection('Title'); ?>
کاربران
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto mt-10 flex flex-col gap-8 max-sm:px-3">
    <form action="<?php echo e(route("users.index")); ?>" class="flex items-cemter">
        <input name="search" type="text" class="rounded-tr-xl rounded-br-xl border-[1px] border-[#B2B2B2] py-2 px-3" placeholder="جستجو">
        <div class="bg-primary flex items-center justify-center rounded-tl-xl rounded-bl-xl px-3">
            <button type="submit"><i class="fa-solid fa-magnifying-glass text-[#FFF]"></i></button>
        </div>
    </form>
    <table class="">
        <thead class="bg-[#B2B2B2] bg-opacity-30 sticky top-0">
            <tr>
                <th class="py-3">نام</th>
                <th class="py-3">شماره</th>
                <th class="py-3">ایمیل</th>
                <th class="py-3">تاریخ تولد</th>
                <th class="py-3">عملیات</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-[1px] border-[#B2B2B2]">
                <td class="text-center py-3"><?php echo e($user->name == null ? "بی نام" : $user->name); ?></td>
                <td class="text-center py-3"><?php echo e($user->phone); ?></td>
                <td class="text-center py-3"><?php echo e($user->email); ?></td>
                <td class="text-center py-3"><?php echo e(\Morilog\Jalali\Jalalian::forge($user->birthday)->format('%B %d، %Y')); ?></td>
                <td class="flex justify-center py-3">
                    <button class="bg-primary text-[#FFFFFF] max-sm:text-lg text-lg p-2 rounded-xl max-sm:mt-3"><a href="<?php echo e(route("users.show",$user->id)); ?>">دوره‌ های خریداری شده</a></button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/uiqhzjxp/public_html/resources/views/users/index.blade.php ENDPATH**/ ?>