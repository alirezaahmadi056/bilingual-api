<?php $__env->startSection('Title'); ?>
ویرایش مقاله
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-center items-center mt-20">
    <form class="flex flex-col gap-5" action="<?php echo e(route("articles.update",$article->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
        <img src="<?php echo e(asset("article_image/".$article->image)); ?>" class="w-96 rounded-xl shadow-2xl" alt="">
        <input type="hidden" name="beforeimage" value="<?php echo e($article->image); ?>">
        <input name="title" type="text" class=" rounded-md border-[#B2B2B2]" placeholder="تایتل" value="<?php echo e($article->title); ?>">
        <textarea name="description" id="" cols="30" rows="10" class=" rounded-md border-[#B2B2B2]" placeholder="توضیخات"><?php echo e($article->description); ?></textarea>
        <label for="image">عکس:</label>
        <input type="file" name="image" id="">
        <button type="submit" class="bg-primary w-full text-[#FFFFFF] text-xl py-2 rounded-xl">ثبت</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/seyed/Desktop/Projects/bilingual/resources/views/articles/edit.blade.php ENDPATH**/ ?>