<?php $__env->startSection("Title"); ?>
افزودن زیرفصل
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="flex justify-center items-center mt-20">
    <form class="flex flex-col gap-5 w-80" action="<?php echo e(route("seasons.sub.store")); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input name="title" type="text" class=" rounded-md border-[#B2B2B2]" placeholder="تایتل">
        <div class="flex flex-col gap-2">
            <label for="season">فصل مورد نظر:</label>
            <select name="season" id="" class=" rounded-md border-[#B2B2B2]">
                <?php $__currentLoopData = $seasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $season): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($season->id); ?>"><?php echo e($season->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button id="success" type="submit" onclick="PleaseWait()" class="bg-primary w-full text-[#FFFFFF] text-xl py-2 rounded-xl">ثبت</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    function PleaseWait() {
      document.getElementById("success").innerHTML = "لطفا صبر کنید ...";
    }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/seyed/Desktop/Projects/bilingual/resources/views/subseason/create.blade.php ENDPATH**/ ?>