<?php $__env->startSection('Title'); ?>
دروه های خریداری شده <?php echo e($name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-center items-center gap-10 flex-wrap mt-10">
    <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $cart->course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="w-80 border-[2px] border-[#b2b2b2] rounded-3xl">
            <img src="<?php echo e(asset("Img/1.png")); ?>" alt="" class="rounded-tl-3xl rounded-tr-3xl">
            <div class="px-6 py-3 flex flex-col gap-5">
                <h1 class="text-2xl text-center font-bold"><?php echo e($course->name); ?></h1>
                <span>قیمت: <?php echo e($course->price); ?> تومان</span>
                <span>وضعیت: <?php if($cart->status == 1): ?> پرداخت شده <?php else: ?> پرداخت نشده <?php endif; ?> </span>
                <p class="border-[1px] border-primary rounded-md py-2 px-3 text-center">لایسنس: <?php echo e($cart->license); ?></p>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/seyed/Desktop/Projects/bilingual/resources/views/users/courses.blade.php ENDPATH**/ ?>